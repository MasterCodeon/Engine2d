
package com.bitfire.postprocessing.effects;

import com.bitfire.postprocessing.PostProcessorEffect;

public abstract class Antialiasing extends PostProcessorEffect {

	public abstract void setViewportSize (int width, int height);
}
