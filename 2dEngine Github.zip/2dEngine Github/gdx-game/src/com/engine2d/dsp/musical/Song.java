package com.engine2d.dsp.musical;

import java.util.*;
import java.lang.*;

public class Song
{
	public String Name = "";
	public ArrayList<Note> Notes;
	public Song()
	{
		Notes = new ArrayList<Note>();
	}
	
	
}
