package com.engine2d;

//IMPORTS
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.graphics.glutils.*;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.viewport.*;
import com.badlogic.gdx.scenes.*;
import com.badlogic.gdx.assets.loaders.*;
import com.bitfire.postprocessing.*;
import com.bitfire.postprocessing.effects.*;
import com.bitfire.utils.*;
import java.time.*;
import org.apache.commons.codec.language.bm.*;
import java.lang.*;
import com.badlogic.gdx.audio.*;
import com.engine2d.UI.*;
import com.engine2d.events.*;
import java.util.*;
import android.util.*;
import com.engine2d.utils.*;
//END IMPORTS

public class Input
{
	public static int KEY_UP = 0;
	public static int KEY_DOWN = 1;
	public static int KEY_TYPED = 2;
	public static int TOUCH_UP= 3;
	public static int TOUCH_DOWN = 4;
	public static int TOUCH_DRAGGED = 5;
	public static int MOUSE_MOVED = 6;
	public static int SCROLLED = 7;
	
	public InputEvent LatestEvent;
	public IEventHandler Handler;
	private Input Ref;
	public Input()
	{
		// Allow the engibe to capture the back key events
		Gdx.input.setCatchBackKey(true);
		
		Handler = new IEventHandler()
		{
			@Override
			public void Handle(InputEvent evt, Input in)
			{
				in.LatestEvent = evt;
			}
		};
		
		Ref = this;
		
		Gdx.input.setInputProcessor(new InputProcessor()
		{
			@Override
			public boolean keyUp(int p1)
			{
				
				if (Handler != null) Handler.Handle( new InputEvent(KEY_UP, new int[] { p1 }), Ref);
				return true;
			}
			
			@Override
			public boolean keyDown(int p1)
			{
				if (Handler != null) Handler.Handle( new InputEvent(KEY_DOWN, new int[] { p1 }), Ref);
				return true;
			}
			
			@Override
			public boolean keyTyped(char p1)
			{
				if (Handler != null) Handler.Handle( new InputEvent(KEY_TYPED, new int[] { p1 }), Ref);
				return true;
			}
			
			@Override
			public boolean mouseMoved(int p1, int p2)
			{
				if (Handler != null) Handler.Handle( new InputEvent(MOUSE_MOVED, new int[] { p1, p2 }), Ref);
				return true;
			}
			
			@Override
			public boolean scrolled(int p1)
			{
				if (Handler != null) Handler.Handle( new InputEvent(SCROLLED, new int[] { p1 }), Ref);
				return true;
			}
			
			@Override
			public boolean touchUp(int p1, int p2, int p3, int p4)
			{
				if (Handler != null) Handler.Handle( new InputEvent(TOUCH_UP, new int[] { p1, p2, p3, p4 }), Ref);
				return true;
			}
			
			@Override
			public boolean touchDown(int p1, int p2, int p3, int p4)
			{
				if (Handler != null) Handler.Handle( new InputEvent(TOUCH_DOWN, new int[] { p1, p2, p3, p4 }), Ref);
				return true;
			}
			
			@Override
			public boolean touchDragged(int p1, int p2, int p3)
			{
				if (Handler != null) Handler.Handle( new InputEvent(TOUCH_DRAGGED, new int[] { p1, p2, p3 }), Ref);
				return true;
			}
		});
	}
}


