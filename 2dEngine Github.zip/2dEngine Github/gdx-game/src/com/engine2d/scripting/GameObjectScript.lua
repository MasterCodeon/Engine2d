function update(obj)

end
