package com.engine2d;

//IMPORTS
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.graphics.glutils.*;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.viewport.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.*;
import com.badlogic.gdx.assets.loaders.*;
import com.bitfire.postprocessing.*;
import com.bitfire.postprocessing.effects.*;
import com.bitfire.utils.*;
import java.time.*;
import org.apache.commons.codec.language.bm.*;
import java.lang.*;
import com.badlogic.gdx.audio.*;
import com.engine2d.UI.*;
import com.engine2d.events.IEvent;
import com.engine2d.utils.*;
import java.util.*;
//END IMPORTS

public class Particle extends GameObject
{
	public Color Color;
	
	public Particle(Scene s)
	{
		super(s);
		
		//this.Location = Location.getRandomLocation(s);
		this.Color = Utils.getRandomColor();
	}

	public Particle(Scene s, boolean addToScene)
	{
		this(s);

		//Adds this GameObject to scene objects
		if (addToScene == true) this.Scene.Objects.Add(this);
	}
	
	@Override
	public void Draw(ShapeRenderer sr)
	{
		sr.begin();
		Scene.ShapeRenderer.setColor(this.Color);
			
		Scene.ShapeRenderer.point((this.Location.x + Scene.Center.x) + Scene.Location.x, (this.Location.y + Scene.Center.y) + Scene.Location.y, 0);
		
		sr.end();
		//sr.rectLine(0, 0, 100, 100, 1, Color.BLUE, Color.RED);
		//sr.line(start.x, start.y, 100, 100);

		//Scene.sr.end();
	}
}
