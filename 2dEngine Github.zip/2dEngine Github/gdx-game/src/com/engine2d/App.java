package com.engine2d;

import com.badlogic.gdx.backends.android.AndroidApplication;
import android.content.Context;
import android.app.*;
public class App
{
	//public static AndroidApplication Instance;
	public static Context Context;
}
